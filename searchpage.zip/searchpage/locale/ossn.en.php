<?php

/**

 * Open Source Social Network

 *

 * @package   SearchPage

 * @author    AT3META <at3meta@3ncircle.com>

 * @copyright 2022 3NCIRCLE Inc.

 * @license   General Public Licence V3

 * @link      https://www.gnu.org/licenses/gpl-3.0.en.html

 */

$en = array(

	'searchpage' => 'searchpage',
	'com:ossn:searchpage' => 'SEARCH',
);
ossn_register_languages('en', $en); 

