
.menu-section-item-searchpage:before{
    content: "\f002" !important
}